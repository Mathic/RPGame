﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using RPGame.Attributes;

namespace RPGame.Characters
{
    class Hero : ICharacter
    {
        private Guid _id;
        private string _name;
        private string _dialog;
        private List<IAttribute> _attributes = 
            new List<IAttribute> { 
            new Strength(), 
            new Constitution(), 
            new Dexterity(), 
            new Wisdom(), 
            new Intelligence(), 
            new Charisma(), 
            new HP(), 
            new MP() };

        #region Constructors

        public Hero()
        {
            _id = Guid.NewGuid();
            _name = "Test";
            _dialog = "Hello World!";
        }

        public Hero(Guid id, string name, string dialog)
        {
            _id = id;
            _name = name;
            _dialog = dialog;
        }

        #endregion

        #region Access Modifiers

        public Guid Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Dialog
        {
            get { return _dialog; }
            set { _dialog = value; }
        }

        public List<IAttribute> Attributes
        {
            get { return _attributes; }
            set { _attributes = value; }
        }

        #endregion

        public void Create()
        {
            foreach (IAttribute attr in _attributes)
            {
                attr.SetPoints(this);
            }
        }

        public override string ToString()
        {
            return "======================\n" +
                "Character Id: " + this.Id.ToString() +
                "\nGreeting: " + this.Dialog +
                "\nNAME:\t" + this.Name +
                "\nSTR:\t" + this.Attributes[0].Points +
                "\nCON:\t" + this.Attributes[1].Points +
                "\nDEX:\t" + this.Attributes[2].Points +
                "\nWIS:\t" + this.Attributes[3].Points +
                "\nINT:\t" + this.Attributes[4].Points +
                "\nCHA:\t" + this.Attributes[5].Points +
                "\nHP:\t" + this.Attributes[6].Points +
                "\nMP:\t" + this.Attributes[7].Points +
                "\n======================\n";
        }
    }
}
