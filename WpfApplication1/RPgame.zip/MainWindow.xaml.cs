﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using RPGame.Characters;
using RPGame.Attributes;
using RPGame.Items;

namespace RPGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Hero hero = new Hero();

        public MainWindow()
        {
            //GamePlay newGame = new GamePlay();
            InitializeComponent();
            RunGame();
        }

        public void RunGame()
        {
            //hero.HeroCreate();
            lbl1.Content = hero.ToString();
        }

        private void startButton_Click(object sender, RoutedEventArgs e)
        {
            lbl2.Content = "Rolling Dice... Please Wait...";
            hero.Create();
            lbl1.Content = hero.ToString();
            lbl2.Content = string.Empty;
        }

        private void equipButton_Click(object sender, RoutedEventArgs e)
        {
            Random rand = new Random();
            Armor arm;
            Weapon wea;
            
            List<IAttribute> attrs = new List<IAttribute> { 
                new Strength(), 
                new Constitution(), 
                new Dexterity(), 
                new Wisdom(), 
                new Intelligence(), 
                new Charisma() };

            foreach (IAttribute a in attrs)
            {
                a.SetPoints(hero);
            }

            arm = new Armor(Guid.NewGuid(),"Test Armor",false,attrs[rand.Next(1,attrs.Count())]);
            wea = new Weapon(Guid.NewGuid(), "Test Armor", false, attrs[rand.Next(1, attrs.Count())]);
            lbl1.Content = arm.ToString() + "\n" + wea.ToString();
        }
    }
}
