﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using RPGame.Attributes;

namespace RPGame.Items
{
    interface IEquippable : IEntity
    {
        bool IsEquipped { get; set; }
        IAttribute Modifier { get; set; }

        void Equip();
        void Create();
    }
}
