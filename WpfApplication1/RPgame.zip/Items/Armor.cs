﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using RPGame.Attributes;

namespace RPGame.Items
{
    class Armor : IEquippable
    {
        private Guid _id;
        private string _name;
        private bool _isEquipped;
        private IAttribute _modifier;

        #region Constructors

        public Armor()
        {
            _id = Guid.NewGuid();
            _name = "";
            _isEquipped = false;
            _modifier = null;
        }

        public Armor(Guid id, string name, bool isUsed, IAttribute modifier)
        {
            _id = id;
            _name = name;
            _isEquipped = isUsed;
            _modifier = modifier;
        }

        #endregion

        #region Access Modifier

        public Guid Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public bool IsEquipped
        {
            get { return _isEquipped; }
            set { _isEquipped = value; }
        }

        public IAttribute Modifier
        {
            get { return _modifier; }
            set { _modifier = value; }
        }

        #endregion

        public void Equip()
        {

        }

        public void Create()
        {

        }

        public override string ToString()
        {
            string equipped = "No";

            if (IsEquipped)
                equipped = "Yes";
            
            return "======================\n" +
                "Armor Id: " + this.Id.ToString() +
                "\nNAME:\t" + this.Name +
                "\nEQP:\t" + equipped +
                this.Modifier.ToString() +
                "\n======================\n";
        }
    }
}
