﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

using RPGame.Characters;

namespace RPGame.Attributes
{

    interface IAttribute : IEntity
    {
        int Points { get; set; }

        void SetPoints(Hero hero);
    }
}
