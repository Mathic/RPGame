﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using RPGame.Characters;

namespace RPGame.Attributes
{
    class HP : IAttribute
    {
        private Guid _id;
        private string _name;
        private int _points;

        public HP(Guid id)
        {
            _id = id;
            _name = "HP";
            _points = 0;
        }

        public HP(Guid id, string name, int points)
        {
            _id = id;
            _name = name;
            _points = points;
        }

        public HP()
        {
            _id = Guid.NewGuid();
            _name = "HP";
            _points = 0;
        }

        public Guid Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int Points
        {
            get { return _points; }
            set { _points = value; }
        }

        public void SetPoints(Hero hero)
        {
            Points = 0;
            int hpModify = (int)Math.Floor((double)(hero.Attributes[1].Points - 10.0) / 2.0);

            Points += hpModify + 100;
        }

        public override string ToString()
        {
            return "\nATT:\t" + this.Name +
                "\nPTS:\t" + this.Points;
        }
    }
}
