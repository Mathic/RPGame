﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

using RPGame.Characters;

namespace RPGame.Attributes
{
    class Constitution : IAttribute
    {
        private const int FOUR = 4;
        private const int SEVEN = 7;
        private Guid _id;
        private string _name;
        private int _points;

        public Constitution(Guid id)
        {
            _id = id;
            _name = "CON";
            _points = 0;
        }

        public Constitution(Guid id, int points)
        {
            _id = id;
            _name = "CON";
            _points = points;
        }

        public Constitution(Guid id, string name, int points)
        {
            _id = id;
            _name = name;
            _points = points;
        }

        public Constitution()
        {
            _id = Guid.NewGuid();
            _name = "CON";
            _points = 0;
        }

        public Guid Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int Points
        {
            get { return _points; }
            set { _points = value; }
        }

        public void SetPoints(Hero hero)
        {
            Points = 0;
            int[] rolls = new int[FOUR];
            int roll;
            Random rand = new Random();

            for (int i = 0; i < FOUR; i++)
            {
                roll = rand.Next(1, SEVEN);
                rolls[i] = roll;
                Thread.Sleep(100);
            }

            Array.Sort(rolls);

            for (int i = FOUR; i > 1; i--)
            {
                Points += rolls[i - 1];
            }
        }

        public override string ToString()
        {
            return "\nATT:\t" + this.Name +
                "\nPTS:\t" + this.Points;
        }
    }
}
