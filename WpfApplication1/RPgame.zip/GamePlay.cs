﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using RPGame.Characters;

namespace RPGame
{
    class GamePlay
    {
        Hero hero = new Hero();
        Hero a = new Hero();

        public void RunGame()
        {
            Console.WriteLine(hero.ToString());
            hero.Create();
            Console.WriteLine(hero.ToString());
        }
    }
}
